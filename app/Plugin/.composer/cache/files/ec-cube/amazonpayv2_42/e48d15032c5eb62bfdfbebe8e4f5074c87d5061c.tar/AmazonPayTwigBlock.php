<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.3   |
    |              on 2022-12-15 15:50:07              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
namespace Plugin\AmazonPayV2_42;use Eccube\Common\EccubeTwigBlock;class AmazonPayTwigBlock implements EccubeTwigBlock{public static function getTwigBlock(){return [];}}