<?php

namespace Plugin\PayPalCheckout42\Exception;

use Exception;

/**
 * Class PayPalCheckoutException
 * @package Plugin\PayPalCheckout42\Exception
 */
class PayPalCheckoutException extends Exception
{
}
