<?php

namespace Plugin\PayPalCheckout42\Exception;

/**
 * Class OrderInitializationException
 * @package Plugin\PayPalCheckout42\Exception
 */
class OrderInitializationException extends PayPalCheckoutException
{
}
