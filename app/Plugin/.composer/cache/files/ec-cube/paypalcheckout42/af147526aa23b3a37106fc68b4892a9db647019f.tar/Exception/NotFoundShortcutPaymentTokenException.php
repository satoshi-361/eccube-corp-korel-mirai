<?php

namespace Plugin\PayPalCheckout42\Exception;

/**
 * Class NotFoundShortcutPaymentTokenException
 * @package Plugin\PayPalCheckout42\Exception
 */
class NotFoundShortcutPaymentTokenException extends PayPalCheckoutException
{
}
