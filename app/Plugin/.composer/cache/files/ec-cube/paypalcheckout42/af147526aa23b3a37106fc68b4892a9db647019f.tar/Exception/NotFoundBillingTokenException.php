<?php

namespace Plugin\PayPalCheckout42\Exception;

/**
 * Class NotFoundBillingTokenException
 * @package Plugin\PayPalCheckout42\Exception
 */
class NotFoundBillingTokenException extends PayPalCheckoutException
{
}
