<?php

namespace Plugin\PayPalCheckout42\Exception;

/**
 * Class NotFoundCartException
 * @package Plugin\PayPalCheckout42\Exception
 */
class NotFoundCartException extends PayPalCheckoutException
{
}
