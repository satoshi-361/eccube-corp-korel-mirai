<?php

namespace Plugin\PayPalCheckout42\Exception;

/**
 * Class ReFoundPaymentException
 * @package Plugin\PayPalCheckout42\Exception
 */
class ReFoundPaymentException extends PayPalCheckoutException
{
}
