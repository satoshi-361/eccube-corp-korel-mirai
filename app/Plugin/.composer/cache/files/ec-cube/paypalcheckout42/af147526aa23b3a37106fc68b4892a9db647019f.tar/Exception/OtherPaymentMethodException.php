<?php

namespace Plugin\PayPalCheckout42\Exception;

class OtherPaymentMethodException extends PayPalCheckoutException
{
}
