<?php

namespace Plugin\PayPalCheckout42\Exception;

/**
 * Class NotFoundPurchaseProcessingOrderException
 * @package Plugin\PayPalCheckout42\Exception
 */
class NotFoundPurchaseProcessingOrderException extends PayPalCheckoutException
{
}
