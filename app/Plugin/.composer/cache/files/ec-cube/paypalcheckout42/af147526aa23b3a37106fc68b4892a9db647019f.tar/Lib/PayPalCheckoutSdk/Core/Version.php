<?php

namespace Plugin\PayPalCheckout42\Lib\PayPalCheckoutSdk\Core;

class Version
{
    const VERSION = "1.0.1";
}
