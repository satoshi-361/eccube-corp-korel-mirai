<?php

namespace Plugin\PayPalCheckout42\Exception;

/**
 * Class ReFoundSubscriptionPaymentException
 * @package Plugin\PayPalCheckout42\Exception
 */
class ReFoundSubscriptionPaymentException extends PayPalCheckoutException
{
}
