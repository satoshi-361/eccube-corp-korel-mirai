<?php
namespace Plugin\CMBlogPro42\Tests\Admin;

use Eccube\Tests\Web\Admin\AbstractAdminWebTestCase;
use Faker\Generator;
use Symfony\Component\HttpKernel\Client;
use Symfony\Component\DomCrawler\Crawler;

/**
 * Class NavTest.
 */
class NavTest extends AbstractAdminWebTestCase
{
    public function testNavigation() {
        $this->assertTrue(true);
    }
}
